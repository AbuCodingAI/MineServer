give @p minecraft:music_disc_11[minecraft:item_model=steves_lava_chicken_extended,minecraft:jukebox_playable="all_the_music:steves_lava_chicken_extended"]
give @p minecraft:music_disc_11[minecraft:item_model=birthday_rap_extended,minecraft:jukebox_playable="all_the_music:birthday_rap_extended"]
give @p minecraft:music_disc_11[minecraft:item_model=ode_to_dennis_extended,minecraft:jukebox_playable="all_the_music:ode_to_dennis_extended"]
give @p minecraft:music_disc_11[minecraft:item_model=welcome_to_steves,minecraft:jukebox_playable="all_the_music:welcome_to_steves"]