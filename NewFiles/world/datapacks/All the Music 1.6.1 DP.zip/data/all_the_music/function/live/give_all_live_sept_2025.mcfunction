give @p music_disc_11[item_model=copper_golem,jukebox_playable='all_the_music:copper_golem',rarity="rare"]
give @p music_disc_11[item_model=nautilus,jukebox_playable='all_the_music:nautlius']
give @p music_disc_11[item_model=spears,jukebox_playable='all_the_music:spears']