give @p minecraft:music_disc_11[minecraft:item_model=axolotl,minecraft:jukebox_playable="all_the_music:axolotl"]
give @p minecraft:music_disc_11[minecraft:item_model=dragon_fish,minecraft:jukebox_playable="all_the_music:dragon_fish"]
give @p minecraft:music_disc_11[minecraft:item_model=shuniji,minecraft:jukebox_playable="all_the_music:shuniji"]