give @p minecraft:music_disc_11[minecraft:item_model=firebugs,minecraft:jukebox_playable="all_the_music:firebugs",minecraft:rarity=rare]
give @p minecraft:music_disc_11[minecraft:item_model=aerie,minecraft:jukebox_playable="all_the_music:aerie",minecraft:rarity=rare]
give @p minecraft:music_disc_11[minecraft:item_model=labyrinthine,minecraft:jukebox_playable="all_the_music:labyrinthine",minecraft:rarity=rare]
give @p minecraft:music_disc_5