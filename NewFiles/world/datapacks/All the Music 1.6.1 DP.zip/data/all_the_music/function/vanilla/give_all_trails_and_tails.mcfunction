give @p minecraft:music_disc_11[minecraft:item_model=a_familiar_room,minecraft:jukebox_playable="all_the_music:a_familiar_room"]
give @p minecraft:music_disc_11[minecraft:item_model=bromeliad,minecraft:jukebox_playable="all_the_music:bromeliad"]
give @p minecraft:music_disc_11[minecraft:item_model=crescent_dunes,minecraft:jukebox_playable="all_the_music:crescent_dunes"]
give @p minecraft:music_disc_11[minecraft:item_model=echo_in_the_wind,minecraft:jukebox_playable="all_the_music:echo_in_the_wind"]
give @p minecraft:music_disc_relic