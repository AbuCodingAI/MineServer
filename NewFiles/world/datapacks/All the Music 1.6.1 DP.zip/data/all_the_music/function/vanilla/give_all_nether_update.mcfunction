give @p minecraft:music_disc_11[minecraft:item_model=chrysopoeia,minecraft:jukebox_playable="all_the_music:chrysopoeia"]
give @p minecraft:music_disc_11[minecraft:item_model=rubedo,minecraft:jukebox_playable="all_the_music:rubedo",minecraft:rarity=rare]
give @p minecraft:music_disc_11[minecraft:item_model=so_below,minecraft:jukebox_playable="all_the_music:so_below"]
give @p minecraft:music_disc_pigstep