give @p minecraft:music_disc_11[minecraft:item_model=lilypad_disc,minecraft:jukebox_playable="all_the_music:lilypad"]
give @p minecraft:music_disc_11[minecraft:item_model=below_and_above,minecraft:jukebox_playable="all_the_music:below_and_above"]
give @p minecraft:music_disc_11[minecraft:item_model=os_piano,minecraft:jukebox_playable="all_the_music:os_piano"]
give @p minecraft:music_disc_11[minecraft:item_model=broken_clocks,minecraft:jukebox_playable="all_the_music:broken_clocks"]
give @p minecraft:music_disc_11[minecraft:item_model=fireflies,minecraft:jukebox_playable="all_the_music:fireflies"]
give @p minecraft:music_disc_tears