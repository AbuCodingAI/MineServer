give @p minecraft:music_disc_11[minecraft:item_model=a_legend_begins,minecraft:jukebox_playable="all_the_music:a_legend_begins"]
give @p minecraft:music_disc_11[minecraft:item_model=unite_the_overworld,minecraft:jukebox_playable="all_the_music:unite_the_overworld"]
give @p minecraft:music_disc_11[minecraft:item_model=fiery_foes,minecraft:jukebox_playable="all_the_music:fiery_foes"]
give @p minecraft:music_disc_11[minecraft:item_model=fiery_foes_2,minecraft:jukebox_playable="all_the_music:fiery_foes_2"]